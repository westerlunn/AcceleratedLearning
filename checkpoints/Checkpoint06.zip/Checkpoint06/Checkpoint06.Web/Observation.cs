﻿using System.Collections.Generic;

namespace Checkpoint06.Web
{
    public class Observation    
    {
        public int Id { get; set; }
        public string Species { get; set; }
        public IEnumerable<Observation> Observations { get; set; }  
    }
}